$(function () {
    $('#id_due_date').datetimepicker({
        timepicker: false,
        format: 'Y-m-d'
    });

});
