$(function() {

    $('#login-modal-button').click(function() {
        $.loadmodal({
            url: '/account/login.modal/',
            title: 'Login',
        })




    });//click


});
