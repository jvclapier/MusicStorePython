$(function() {

    $('#login-modal-form > form').ajaxForm({
        target: '#jquery-loadmodal-js-body',
    });
});
