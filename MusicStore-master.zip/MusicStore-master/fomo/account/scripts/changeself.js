$(function () {
    $('#id_birthday').datetimepicker({
        timepicker: false,
        format: 'Y-m-d'
    });

});
