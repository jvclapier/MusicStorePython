from django.contrib import admin
from account.models import FOMOUser

#register your models here.
admin.site.register(FOMOUser)
